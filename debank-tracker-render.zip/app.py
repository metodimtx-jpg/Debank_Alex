#!/usr/bin/env python3
import os
import time
import threading
import requests
import json
from datetime import datetime

# Configuration via environment variables (set these in Render env vars)
BOT_TOKEN = os.getenv("TELEGRAM_TOKEN")      # Set your Telegram bot token on Render
CHAT_ID = os.getenv("CHAT_ID")               # Numeric chat ID (example: 1827049213)
ADDRESS = os.getenv("TARGET_ADDRESS", "0xc937367b858bfd43ea1ab01fd6faf9732b27ace5")
CHECK_INTERVAL = int(os.getenv("CHECK_INTERVAL", "30"))  # seconds

STATE_FILE = "state.json"
BASELINE_FILE = "baseline.json"

# Helper: send Telegram message (simple HTTP API)
def send_message(text):
    if not BOT_TOKEN or not CHAT_ID:
        print("Missing BOT_TOKEN or CHAT_ID. Cannot send message.")
        return
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    try:
        resp = requests.post(url, data={"chat_id": CHAT_ID, "text": text})
        if resp.status_code != 200:
            print("Telegram send failed:", resp.status_code, resp.text)
    except Exception as e:
        print("Exception sending Telegram message:", e)

# Load/save JSON helpers
def load_json(fn):
    try:
        with open(fn, "r") as f:
            return json.load(f)
    except Exception:
        return {}

def save_json(fn, data):
    with open(fn, "w") as f:
        json.dump(data, f, indent=2)

# --- DeBank API helpers (best-effort, public endpoints) ---
def fetch_token_list(address):
    url = f"https://api.debank.com/user/token_list?id={address}&is_all=true"
    try:
        r = requests.get(url, timeout=15)
        r.raise_for_status()
        payload = r.json()
        return payload.get("data", [])
    except Exception as e:
        print("Error fetching token list:", e)
        return []

def fetch_tx_list(address, count=20):
    # Best-effort: DeBank has public transaction endpoints; if unavailable, this returns empty list
    url = f"https://api.debank.com/user/transaction_list?id={address}&chain=&limit={count}"
    try:
        r = requests.get(url, timeout=15)
        r.raise_for_status()
        payload = r.json()
        return payload.get("data", [])
    except Exception as e:
        print("Error fetching tx list:", e)
        return []

# Simplify tokens into dict {token_id: {amount, symbol, usd_value}}
def simplify_tokens(tokens):
    simplified = {}
    for t in tokens:
        try:
            token_id = t.get("id") or t.get("token_id") or t.get("contract_address") or t.get("symbol", "UNKNOWN")
            # amount: try different fields
            amount = 0.0
            if t.get("amount") is not None:
                amount = float(t.get("amount") or 0)
            elif t.get("raw_amount") is not None and t.get("decimals") is not None:
                amount = float(t["raw_amount"]) / (10 ** int(t["decimals"]))
            # USD value: try direct fields or compute if price available
            usd_value = None
            if t.get("amount_usd") is not None:
                usd_value = float(t.get("amount_usd") or 0)
            else:
                price = t.get("price") or t.get("usd_price") or t.get("native_price", {}).get("value")
                if price is not None:
                    try:
                        usd_value = float(price) * amount
                    except Exception:
                        usd_value = None
            simplified[token_id] = {
                "symbol": t.get("symbol") or t.get("name") or token_id,
                "amount": amount,
                "usd": usd_value if usd_value is not None else 0.0
            }
        except Exception as e:
            print("Error simplifying token:", e)
    return simplified

# Compute total USD value from simplified tokens
def total_usd(tokens_simplified):
    total = 0.0
    for v in tokens_simplified.values():
        # usd might be 0 if not provided; skip if zero and no reliable price
        try:
            total += float(v.get("usd", 0) or 0)
        except Exception:
            pass
    return total

# --- Monitoring loop ---
def monitor_loop():
    state = load_json(STATE_FILE)
    last_tokens = state.get("last_tokens", {})
    last_tx_hashes = set(state.get("last_tx_hashes", []))

    # If baseline exists, load it; otherwise baseline will be created on first run
    baseline = load_json(BASELINE_FILE)
    baseline_value = baseline.get("total_usd") if baseline else None

    send_message(f"🔍 DeBank tracker started for {ADDRESS}. Checks every {CHECK_INTERVAL}s.")

    while True:
        try:
            tokens = fetch_token_list(ADDRESS)
            simplified = simplify_tokens(tokens)
            now_hashes = set()

            # Detect token additions/removals
            added = set(simplified.keys()) - set(last_tokens.keys())
            removed = set(last_tokens.keys()) - set(simplified.keys())

            # Detect balance changes (by token id)
            changed = []
            for tid, info in simplified.items():
                old_amt = last_tokens.get(tid, {}).get("amount", 0)
                new_amt = info.get("amount", 0)
                # Use a relative threshold to avoid noise
                if abs(new_amt - old_amt) > max(1e-8, 0.000001 * max(abs(old_amt), abs(new_amt), 1)):
                    changed.append((tid, last_tokens.get(tid, {}).get("symbol", tid), old_amt, new_amt))

            # Compute total USD value
            total = total_usd(simplified)

            # Transaction alerts
            txs = fetch_tx_list(ADDRESS, count=30)
            new_txs = []
            for tx in txs:
                tx_hash = tx.get("hash") or tx.get("id") or tx.get("tx_hash")
                if not tx_hash:
                    continue
                now_hashes.add(tx_hash)
                if tx_hash not in last_tx_hashes:
                    new_txs.append(tx)

            messages = []
            if added:
                messages.append("🟢 New token(s) added:\n" + "\n".join([f\"{simplified.get(a,{}).get('symbol',a)} ({a})\" for a in added]))
            if removed:
                messages.append("🔴 Token(s) removed:\n" + "\n".join(list(removed)))
            if changed:
                lines = [f\"{symbol}: {old} → {new}\" for (tid, symbol, old, new) in changed]
                messages.append("📈 Balance changes:\n" + "\n".join(lines))
            if new_txs:
                tx_lines = []
                for tx in new_txs:
                    th = tx.get('hash') or tx.get('id') or tx.get('tx_hash')
                    direction = tx.get('transfer_type') or tx.get('type') or tx.get('action') or 'tx'
                    value = tx.get('value') or tx.get('amount') or tx.get('usd_value') or ""
                    tx_lines.append(f\"{th} {direction} {value}\")
                messages.append("🔔 New transactions:\n" + "\n".join(tx_lines))

            # If messages were detected, send a single combined message
            if messages:
                header = f\"📝 Update for {ADDRESS} — total ≈ ${total:,.2f}\\nTime: {datetime.utcnow().isoformat()}Z\\n\\n\"
                body = \"\\n\\n\".join(messages)
                send_message(header + body)

            # Save state
            last_tokens = simplified
            last_tx_hashes = set([tx.get('hash') or tx.get('id') or tx.get('tx_hash') for tx in txs if (tx.get('hash') or tx.get('id') or tx.get('tx_hash'))])
            save_json(STATE_FILE, {"last_tokens": last_tokens, "last_tx_hashes": list(last_tx_hashes)})

            # Baseline handling (create on first run if not exist)
            if baseline_value is None:
                baseline_value = total
                save_json(BASELINE_FILE, {"total_usd": baseline_value, "created_at": datetime.utcnow().isoformat()})
                send_message(f"📌 Baseline created: total USD ≈ ${baseline_value:,.2f}. Use /setbaseline to update later.")

            # Optional: notify if total changes significantly compared to baseline (example >1% change)
            try:
                if baseline_value and baseline_value > 0:
                    pct = (total - baseline_value) / baseline_value * 100.0
                    if abs(pct) >= 1.0:  # threshold 1%
                        send_message(f\"📊 Portfolio vs baseline: ${total:,.2f} ({pct:+.2f}% vs baseline ${baseline_value:,.2f})\")
            except Exception as e:
                print(\"Baseline compare error:\", e)

        except Exception as e:
            print(\"Monitor loop error:\", e)
            send_message(f\"⚠️ Monitor error: {e}\")

        time.sleep(CHECK_INTERVAL)

# --- Telegram command handler (long polling) ---
def handle_update(update):
    # update is a dict from getUpdates
    if 'message' not in update:
        return
    msg = update['message']
    text = msg.get('text','').strip()
    chat = msg.get('chat',{})
    chat_id = chat.get('id')
    if str(chat_id) != str(CHAT_ID):
        # ignore commands from others
        return

    if text.startswith('/'):
        parts = text.split()
        cmd = parts[0].lower()
        if cmd == '/portfolio':
            tokens = simplify_tokens(fetch_token_list(ADDRESS))
            lines = [f\"{v.get('symbol')} — {v.get('amount')} — ${v.get('usd',0):,.2f}\" for k,v in tokens.items()]
            total = total_usd(tokens)
            send_message(\"📋 Current portfolio:\\n\" + \"\\n\".join(lines[:30]) + f\"\\n\\nTotal ≈ ${total:,.2f}\")
        elif cmd == '/value':
            tokens = simplify_tokens(fetch_token_list(ADDRESS))
            total = total_usd(tokens)
            send_message(f\"💰 Total portfolio value ≈ ${total:,.2f}\")
        elif cmd == '/changes':
            state = load_json(STATE_FILE)
            last = state.get('last_tokens', {})
            msg_lines = []
            for k,v in last.items():
                msg_lines.append(f\"{v.get('symbol')} — {v.get('amount')} — ${v.get('usd',0):,.2f}\")
            send_message(\"📈 Last saved snapshot:\\n\" + \"\\n\".join(msg_lines[:50]))
        elif cmd == '/setbaseline':
            # allow user to set baseline to current value or to a provided number: /setbaseline 1234.56
            if len(parts) >= 2:
                try:
                    value = float(parts[1])
                    save_json(BASELINE_FILE, {\"total_usd\": value, \"created_at\": datetime.utcnow().isoformat()})
                    send_message(f\"✅ Baseline set to ${value:,.2f}\")
                except Exception as e:
                    send_message(\"⚠️ Could not parse number. Use /setbaseline 1234.56 or just /setbaseline to use current value.\")
            else:
                tokens = simplify_tokens(fetch_token_list(ADDRESS))
                total = total_usd(tokens)
                save_json(BASELINE_FILE, {\"total_usd\": total, \"created_at\": datetime.utcnow().isoformat()})
                send_message(f\"✅ Baseline set to current total ${total:,.2f}\")
        else:
            send_message(\"Unknown command. Available: /portfolio, /value, /changes, /setbaseline\")

def updates_loop():
    offset = None
    while True:
        try:
            if not BOT_TOKEN:
                time.sleep(5)
                continue
            url = f\"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates?timeout=30\" + (f\"&offset={offset}\" if offset else \"\")
            r = requests.get(url, timeout=35)
            r.raise_for_status()
            data = r.json()
            for u in data.get('result', []):
                offset = (u.get('update_id') or 0) + 1
                handle_update(u)
        except Exception as e:
            print(\"Updates loop error:\", e)
            time.sleep(5)

if __name__ == '__main__':
    # Start monitor loop thread
    t = threading.Thread(target=monitor_loop, daemon=True)
    t.start()

    # Start updates loop in main thread (so the process keeps running)
    updates_loop()
